﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirstWithEF_Project.Models.Repository
{
    public interface IDataRepository<Employee>
    {
        IEnumerable<Employee> GetAll();
        Employee Get(long id);
        void Add(Employee entity);
        void Update(Employee dbEntity, Employee entity);
        void Delete(Employee entity);
    }
}
